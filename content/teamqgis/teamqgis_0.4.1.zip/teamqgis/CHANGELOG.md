# Changelog for "teamqgis"

## 0.5

* Don't output multiple warnings for a single feature for classes that are not 
  marked as allowed

## 0.4
* Fix error with setting class combo box when classes are numeric codes.

## 0.3
* Fix startup error due to missing qgissettingmanager submodule..

## 0.2
* Fix website address.

## 0.1
* Initial release
